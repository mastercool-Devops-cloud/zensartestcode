package com.customer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.customer.dto.CustomerDto;
import com.customer.dto.LoginDTO;
import com.customer.dto.PlanDTO;
import com.customer.dto.RegisterDTO;
import com.customer.entity.Customer;
import com.customer.repository.CustomerRepository;
import com.customer.service.ICustomerService;

@RestController
/* @RequestMapping("/test") */
//@RibbonClient(name="custribbon")
public class CustomerRestController {
	// private static String PLAN_URL="http://localhost:4343/PlanApi/{planId}";
	// private static String
	// FRIEND_URL="http://localhost:4242/FriendApi/{phoneNumber}";
	// private static String FRIEND_URL="http://custribbon/FriendApi/{phoneNumber}";

	
	@Autowired
	private ICustomerService service;

	@Autowired
	CustomerRepository repository;

	@Autowired
	@Qualifier("restTemplate")
	private RestTemplate restTemplate;

	@Autowired
	@Qualifier("restTemplate2")
	private RestTemplate loadBalancedRestTemplate;

	@PostMapping("/register")
	public boolean addCustomer(@RequestBody RegisterDTO registerDto) {
		return service.registerCustomer(registerDto);
	}

	@PostMapping("/login")
	public boolean loginCustomer(@RequestBody LoginDTO loginDto) {
		return service.loginCustomer(loginDto);
	}

	@GetMapping("/viewProfile/{phoneNumber}")
	public CustomerDto test(@PathVariable Long phoneNumber) {
		//Customer customer = repository.findById(phoneNumber).get();
		CustomerDto customerdto = new CustomerDto();
		customerdto = service.readCustomer(phoneNumber);
		
		
		  String PLAN_URL = "http://planmicro/" + customerdto.getPlanId();
		  PlanDTO planDto = restTemplate.getForObject(PLAN_URL, PlanDTO.class);
		  customerdto.setCurrentPlan(planDto);
		 
		
		return customerdto;
	}

	/*
	 * @GetMapping("/viewcustprofile/{phoneNumber}") public Customer
	 * readCustomer(@PathVariable Long phoneNumber) { Customer customer =
	 * repository.findById(phoneNumber).get();
	 * System.out.println("************************" + customer);
	 * 
	 * CustomerDto customerDto=new CustomerDto(); BeanUtils.copyProperties(customer,
	 * customerDto);
	 * 
	 * 
	 * return customer; }
	 */

	
	
	/*
	 * @GetMapping("/viewProfile/{phoneNumber}") public CustomerDto
	 * customerProfile(@PathVariable Long phoneNumber) { // CustomerDto customerDto
	 * = service.readCustomer(phoneNumber); CustomerDto customerDto = new
	 * CustomerDto(); String PLAN_URL = "http://localhost:4343/PlanApi/" + "111";
	 * String FRIEND_URL = "http://localhost:4242/FriendApi/" + phoneNumber;
	 * 
	 * // calling plan-microservice
	 * 
	 * PlanDTO planDto = restTemplate.getForObject(PLAN_URL, PlanDTO.class);
	 * 
	 * customerDto.setCurrentPlan(planDto);
	 * 
	 * ResponseEntity<List<Long>> response =
	 * loadBalancedRestTemplate.exchange(FRIEND_URL, HttpMethod.GET, null, new
	 * ParameterizedTypeReference<List<Long>>() { });
	 * 
	 * List<Long> friendsContactNumbers = response.getBody();
	 * customerDto.setFriendsContactNumbers(friendsContactNumbers);
	 * 
	 * // calling friend-microservice
	 * 
	 * ParameterizedTypeReference<List<Long>> typeRef = new
	 * ParameterizedTypeReference<List<Long>>() { }; ResponseEntity<List<Long>> re =
	 * loadBalancedRestTemplate.exchange(FRIEND_URL, HttpMethod.GET, null, typeRef,
	 * phoneNumber); List<Long> friendsContactList = re.getBody();
	 * customerDto.setFriendsContactNumbers(friendsContactList);
	 * 
	 * return customerDto;
	 * 
	 * }
	 */
	 
	 
}
