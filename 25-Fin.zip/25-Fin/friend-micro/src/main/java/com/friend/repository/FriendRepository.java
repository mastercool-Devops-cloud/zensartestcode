package com.friend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import com.friend.entity.Friend;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface FriendRepository extends JpaRepository<Friend, Integer> {
	
	@Query(value="select count(*) from friend where  phone_no=?  and  friend_no=?", nativeQuery=true)
	Integer  checkFriendContact(Long phoneNumber, Long friendNumber);
	
	@Query(value="select  friend_no  from  friend  where  phone_no=?", nativeQuery=true)
	List<Long>  findFriendsContactNumbers(Long phoneNumber);

	//void deleteByPhoneNumber(Long phoneNumber);
	
	@Modifying
    @Transactional
    @Query("DELETE FROM Friend r WHERE r.phoneNumber = :phoneNumber")
    void deleteByPhoneNumber(@Param("phoneNumber") Long phoneNumber);

	

}
