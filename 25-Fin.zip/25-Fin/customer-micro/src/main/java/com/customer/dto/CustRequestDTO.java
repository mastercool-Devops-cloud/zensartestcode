package com.customer.dto;

public class CustRequestDTO {
	
	private Integer id;

	private Long friendNumber;
	
	private Long phoneNumber;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long getFriendNumber() {
		return friendNumber;
	}

	public void setFriendNumber(Long friendNumber) {
		this.friendNumber = friendNumber;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
		
	
	//private FriendUpdateRequestDTO friendUpdateRequestDTO;
	
	
	
	

}
