package com.customer.dto;

public class FriendUpdateRequestDTO {
	
	private Integer id;


	private Long friendNumber;
	

	public FriendUpdateRequestDTO() {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	

	public Long getFriendNumber() {
		return friendNumber;
	}

	public void setFriendNumber(Long friendNumber) {
		this.friendNumber = friendNumber;
	}
	
	
	
	
	
	



}
