package com.customer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.customer.dto.CompleteDTO;
import com.customer.dto.CustRequestDTO;
import com.customer.dto.CustomerDto;
import com.customer.dto.FriendUpdateRequestDTO;
import com.customer.dto.LoginDTO;
import com.customer.dto.PlanDTO;
import com.customer.dto.RegisterDTO;
import com.customer.entity.Customer;
import com.customer.repository.CustomerRepository;
import com.customer.service.ICustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerRestController {

	@Autowired
	private ICustomerService service;

	@Autowired
	CustomerRepository repository;

	@Autowired
	@Qualifier("restTemplate")
	private RestTemplate restTemplate;

	
	  @Autowired	  
	  @Qualifier("restTemplate2") 
	  private RestTemplate loadBalancedRestTemplate;
	 

	@PostMapping("/register")
	public boolean addCustomer(@RequestBody RegisterDTO registerDto) {
		return service.registerCustomer(registerDto);
	}
	
	@PostMapping("/custProfileRegister")
	public  void addAllCustomer(@RequestBody CompleteDTO completeDTO) {
		 service.completeCustomerDetails(completeDTO);
		 
		 FriendUpdateRequestDTO friendUpdateRequestDTO = new FriendUpdateRequestDTO();
		 friendUpdateRequestDTO = completeDTO.getFriendUpdateRequestDTO();
		 CustRequestDTO custRequestDTO = new CustRequestDTO();
		 custRequestDTO.setFriendNumber(friendUpdateRequestDTO.getFriendNumber());
		 custRequestDTO.setId(friendUpdateRequestDTO.getId());
		 custRequestDTO.setPhoneNumber(completeDTO.getPhoneNumber());
		 
		 
		 String url = "http://friendmicro/friend/addFriend";
		 
	        restTemplate.postForEntity(url, custRequestDTO, Void.class);
		 
		
	}

	@PostMapping("/login")
	public boolean loginCustomer(@RequestBody LoginDTO loginDto) {
		return service.loginCustomer(loginDto);
	}

	@GetMapping("/viewProfile/{phoneNumber}")
	public CustomerDto fetchCustProfile(@PathVariable Long phoneNumber) {
		CustomerDto customerdto = new CustomerDto();
		customerdto = service.readCustomer(phoneNumber);		
		
		  String PLAN_URL = "http://planmicro/plan/" + customerdto.getPlanId(); 
		  PlanDTO planDto = restTemplate.getForObject(PLAN_URL, PlanDTO.class);
		  customerdto.setCurrentPlan(planDto);
		 
		// calling friend-microservice
		  String FRIEND_URL = "http://friendmicro/friend/" + phoneNumber; 
		  ParameterizedTypeReference<List<Long>> typeRef = new ParameterizedTypeReference<List<Long>>() { }; 
		  ResponseEntity<List<Long>> re = loadBalancedRestTemplate.exchange(FRIEND_URL, HttpMethod.GET, null, typeRef); 
		  List<Long> friendsContactList = re.getBody();
		  customerdto.setFriendsContactNumbers(friendsContactList);
		
		return customerdto;
	}
	
	 @DeleteMapping("deleteCustomerProfile/{phoneNumber}")
	    public ResponseEntity<Void> deleteRecord(@PathVariable Long phoneNumber) {
		 service.deleteRecord(phoneNumber);
		 
		 String FRIEND_URL = "http://friendmicro/friend/deleteFriend/" + phoneNumber; 
		 
		 restTemplate.delete(FRIEND_URL);
		 
	        return ResponseEntity.noContent().build();
	    }
}
