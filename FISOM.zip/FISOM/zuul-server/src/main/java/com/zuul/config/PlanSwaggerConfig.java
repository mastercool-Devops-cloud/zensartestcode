package com.zuul.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import io.swagger.v3.oas.models.OpenAPI;

import io.swagger.v3.oas.models.info.Info;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PlanSwaggerConfig  implements WebMvcConfigurer{
	
	 @Bean
	    public GroupedOpenApi planMicroApi() {
	        return GroupedOpenApi.builder()
	                .group("planmicro")
	                .pathsToMatch("/planmicro/**")
	                .build();
	    }
	 
	 @Bean
	    public GroupedOpenApi friendMicroApi() {
	        return GroupedOpenApi.builder()
	                .group("friendmicro")
	                .pathsToMatch("/friendmicro/**")
	                .build();
	    }
	 
	 @Bean
	    public GroupedOpenApi customerMicroApi() {
	        return GroupedOpenApi.builder()
	                .group("customermicro")
	                .pathsToMatch("/customermicro/**")
	                .build();
	    }
	 
	 
	
	@Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*") // Update with your Swagger UI host
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
	
}
