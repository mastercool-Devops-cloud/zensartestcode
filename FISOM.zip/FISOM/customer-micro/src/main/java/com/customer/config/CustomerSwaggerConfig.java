package com.customer.config;

	import org.springdoc.core.GroupedOpenApi;
	import org.springframework.context.annotation.Bean;
	import org.springframework.context.annotation.Configuration;
	import org.springframework.web.servlet.config.annotation.CorsRegistry;
	import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

	import io.swagger.v3.oas.models.OpenAPI;

	import io.swagger.v3.oas.models.info.Info;

	@Configuration
	public class CustomerSwaggerConfig implements WebMvcConfigurer {
		
		 @Bean
		    public GroupedOpenApi publicApi() {
		        return GroupedOpenApi.builder()
		                .group("customermicro")
		                .pathsToMatch("/customer/**")
		                .build();
		    }
		 
		 @Override
		    public void addCorsMappings(CorsRegistry registry) {
		        registry.addMapping("/**")
		                .allowedOrigins("*") // Use specific origins in production for security
		                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
		                .allowedHeaders("*")
		                .allowCredentials(true);
		    }
		 
		

	}

	


